class Solution(object):
    def reverseString(self, s):
        """
        :type s: str
        :rtype: str
        """
        # slice
        return s[::-1]