class Solution {
    public String reverseStr(String s, int k) {
        // https://leetcode.com/problems/reverse-string-ii/solution/
        char[] a = s.toCharArray();
        for (int start = 0; start < a.length; start += 2 * k) {
            int i = start, j = Math.min(start + k - 1, a.length - 1);
            // Reverse from i to j
            while (i < j) {
                char tmp = a[i];
                a[i++] = a[j];
                a[j--] = tmp;
            }
        }
        return new String(a);
    }
}
